package com.hhit.basetrain.dao;

import com.hhit.basetrain.entity.Teaching;

public interface TeachingDao {
	public int savestudycheck(Teaching tea);
	public int savestudyplan(Teaching tea);
}
