/**
 * 
 */
package com.hhit.basetrain.dao;

import java.util.Map;

/**
 *@author hulijie
 * @date 2016-4-28t下午03:55:04
 * TODO
 */
public interface AssessScoreDao {

	public int save(Map<String, Object> map);
}
